/**
 * @mainpage Course and Student functions demonstration
 * 
 * The Course and Student functions demonstration shows how multiple functions in the course and student
 * libraries work, including: 
 *  - Enrolling students into a course
 *  - Printing course and student information
 *  - Searching for the highest averaging student enrolled in a course
 *  - Getting an array of students who passed the course and the number of students who passed the course
 *  - Printing a student's information
 *  - Generating random students 
 * 
 * @file main.c
 * @author Andy Luo
 * @date 2022/04/08
 * @brief Runs demonstration code for course library methods.
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates a course of students represented by the Course typedef struct and tests the course and student
 * library methods for generating random students, enrolling students, printing course and student information,
 * finding the top student of a course, and getting an array of all the passing students of the course and the total number of passing students
 * 
 */

int main()
{
  srand((unsigned) time(NULL));

  //creates a course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //enrolls random students into the course by generating random students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //prints the course information
  print_course(MATH101);

  //prints out the student information of the top student of the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //prints out the total number of passing students and the information of each passing student
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}