/**
 * @file student.h
 * @author Andy Luo
 * @date 2022/04/08
 * @brief Student library for managing students, including student type definition 
 *        and Student functions.
 *
 */ 

/**
* Student type stores a student with fields first_name, last_name, id, grades, num_grades.
*
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name*/
  char last_name[50]; /**< the student's last name*/
  char id[11]; /**< the student's id*/
  double *grades; /**< the list of the student's grades*/
  int num_grades; /**< the total number of grades the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
