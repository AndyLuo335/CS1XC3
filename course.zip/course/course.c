/**
 * @file course.c
 * @author Andy Luo
 * @date 2022/04/08
 * @brief Course library for managing courses, including definitions of Course functions.
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>


/** 
 * The function 'enroll_student' recieves a course and student as inputs and enrolls the student into the course. 
 * 
 * @param course a course of students represented by a Course variable.
 * @param student a student represented by a Student variable.
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
 
  /* if total_students == 1, then we use calloc to allocate space for the student because
   the dynamic array has not been previously allocated any space as there were no students.
   Otherwise, we use realloc to reallocate the students array to an array of length total_students to make space for the new student. 
  */
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}


/** 
 * The function 'print_course' recieves a course as an input and prints the courses' name, code, total number of students
 * and the first name, last name, student id, grade and average grade of each of its enrolled students.
 *
 * @param course a course of students represented by a Course variable.
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  
  // loops through the array containing all the enrolled students and prints them out
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}


/** 
 * The function 'top_student' recieves a course as an input and returns the student with highest average grade in the course.
 * If the course has no students, then it returns NULL.
 * 
 * @param course a course of students represented by a Course variable.
 * @return the top student represented by a Student variable.
 */

Student* top_student(Course* course)
{
  // if total_students equals 0, then we return NULL. Otherwise, we search for the student with the highest average by looping through the array of enrolled students.
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * The function 'passing' recieves a course and a counter for the total number of passing students by reference
 * and counts the total number of students that passed the course and returns an array of the students who passed.
 * It modifies the counter it recieves as an input to equal the total number of passing students.
 * If there are no students in the course, then it will return NULL
 * 
 * @param course a course of students represented by a typedef struct.
 * @param total_passing a count of the total number of passing students represented by an integer 
 * @return a list of the students who passed represented by a Student array.
 */


Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // This loop counts the total number of passing students by iterating through the students array.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  // This loop stores the students who passed in an array called passing by iterating through the students array.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}