/**
 * @file student.c
 * @author Andy Luo
 * @date 2022/04/08
 * @brief Student library for managing students, including definitions of Student functions.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/**
 * The function 'add_grade' recieves a student and a grade as inputs and adds the new grade to the student's list of grades.
 * 
 * @param student a student represented by a Student variable.
 * @param grade a number grade represented by a double variable.
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  /* if num_grades == 1, then we use calloc to allocate space for the grade because
   the dynamic array has not been previously allocated any space as there were no grades.
   Otherwise, we use realloc to reallocate the grades array to an array of length num_gradess to make space for the new student. 
  */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  //adds the new grade to the end of the grades list.
  student->grades[student->num_grades - 1] = grade;
}

/**
 * The function 'average' recieves a student as an input and returns the average of the students grades.
 * If the student has no grades, then it returns 0.
 * 
 * @param student a student represented by a Student variable.
 * @return the average of the students grades represented by a double variable.
 */

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  //iterates through the grades array and stores the total sum of the students grades in total.
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];

  return total / ((double) student->num_grades);
}

/**
 * The function 'print_student' recieves a student and prints the student's first and last name,
 * their id, all their grades, and the average of all their grades.
 * 
 * @param student a student represented by a Student variable.
 * @return nothing
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  
  // iterates through the grades array and prints out all the student's grades.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * The function 'generate_random_student' recieves a total number of grades and generates a student 
 * whose first and last name are randomly selected from an array of first names and an array of last names,
 * student id is a random 10-digit number, and a list of random grades whose size is the inputted number.
 * It then returns the generated student.
 * 
 * @param grades the total number of grades the student has represented by an integer.
 * @return a randomly generated student represented by a Student variable.
 */

Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  Student *new_student = calloc(1, sizeof(Student));
  
  //generates the student's randomly selected first and last names
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //generates the student's random 10-digit id.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //generates the student's random grades.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}